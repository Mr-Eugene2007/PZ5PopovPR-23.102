// Подключение Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
import { getAuth, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

// Конфигурация Firebase
const firebaseConfig = {
    apiKey: "AIzaSyA0JZ3t8nAcbPlJhx3VZffhyj1eHKlMZVY",
    authDomain: "webgameshop-f3b88.firebaseapp.com",
    databaseURL: "https://webgameshop-f3b88-default-rtdb.firebaseio.com",
    projectId: "webgameshop-f3b88",
    storageBucket: "webgameshop-f3b88.appspot.com",
    messagingSenderId: "206785674970",
    appId: "1:206785674970:web:9256144bd9feb69dac6fe3",
    measurementId: "G-S4KC1TBQ8S"
};


// Инициализация Firebase
const app = firebase.initializeApp(firebaseConfig);
const database = firebase.database();
const auth = firebase.auth();

// Проверка авторизации при загрузке
document.addEventListener('DOMContentLoaded', function() {
    auth.onAuthStateChanged(user => {
        if (!user) {
            window.location.href = 'authorization.html';
        } else {
            loadUserData(user);
            setupEventListeners();
        }
    });
});

async function loadUserData(user) {
    try {
        // Установка данных пользователя
        const username = user.email.split('@')[0];
        document.querySelectorAll('#username-display, #sidebarUsername, #mainUsername').forEach(el => {
            el.textContent = username;
        });
        document.getElementById('userEmail').textContent = user.email;
        
        // Загрузка дополнительных данных из базы
        const userRef = database.ref('users/' + user.uid);
        const snapshot = await userRef.once('value');
        const userData = snapshot.val();
        
        if (userData) {
            // Обновление аватара
            if (userData.avatar) {
                document.getElementById('userAvatar').src = userData.avatar;
            }
            
            // Обновление статистики
            if (userData.games) {
                document.getElementById('gamesCount').textContent = Object.keys(userData.games).length;
            }
            
            if (userData.friends) {
                document.getElementById('friendsCount').textContent = Object.keys(userData.friends).length;
            }
            
            if (userData.balance) {
                document.getElementById('balance').textContent = userData.balance;
            }
            
            // Проверка на админа и показ кнопки
            if (userData.role === 'admin') {
                document.getElementById('adminNewsButton').style.display = 'block';
            }
            
            // Загрузка игр
            if (userData.games) {
                loadUserGames(userData.games);
            }
        }
    } catch (error) {
        console.error('Ошибка загрузки данных:', error);
    }
}

function loadUserGames(games) {
    const gamesList = document.getElementById('gamesList');
    gamesList.innerHTML = '';
    
    Object.entries(games).forEach(([gameId, game]) => {
        const gameCard = document.createElement('div');
        gameCard.className = 'bg-yellow-100 dark:bg-orange-200 p-4 rounded-lg shadow';
        gameCard.innerHTML = `
            <img src="${game.image || 'images/game-placeholder.png'}" alt="${game.name}" class="w-full h-40 object-cover rounded-md mb-2">
            <h3 class="text-lg font-bold text-black">${game.name}</h3>
            <p class="text-black text-sm">${game.description || 'Описание отсутствует'}</p>
            <div class="mt-2 flex justify-between items-center">
                <span class="text-black text-sm">${game.lastPlayed ? 'Играли: ' + game.lastPlayed : 'Еще не играли'}</span>
                <button class="text-black bg-yellow-300 hover:bg-yellow-400 focus:ring-4 focus:outline-none focus:ring-yellow-300 font-medium rounded-lg text-sm px-4 py-2 text-center dark:bg-orange-400 dark:hover:bg-orange-500 dark:focus:ring-orange-400"
                    onclick="launchGame('${gameId}')">
                    Играть
                </button>
            </div>
        `;
        gamesList.appendChild(gameCard);
    });
}

async function logout() {
    try {
        await auth.signOut();
        // Очищаем localStorage при выходе
        localStorage.removeItem('userID');
        localStorage.removeItem('isAdmin');
        // Перенаправляем на главную страницу
        window.location.href = 'index.html';
    } catch (error) {
        console.error('Ошибка при выходе:', error);
        alert('Произошла ошибка при выходе. Пожалуйста, попробуйте ещё раз.');
    }
}

function showSection(sectionId) {
    // Скрыть все секции
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.add('hidden');
    });
    
    // Показать выбранную секцию
    document.getElementById(sectionId + 'Section').classList.remove('hidden');
}

function toggleTheme() {
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('darkMode', document.documentElement.classList.contains('dark'));
}

function setupEventListeners() {
    // Проверка сохраненной темы
    if (localStorage.getItem('darkMode') === 'true') {
        document.documentElement.classList.add('dark');
    }
    
    // Показать секцию игр по умолчанию
    showSection('games');
    
    // Назначаем обработчик для кнопки выхода
    document.getElementById('logoutButton').addEventListener('click', logout);
}

// Функции для демонстрации
function launchGame(gameId) {
    alert('Запуск игры с ID: ' + gameId);
}

function updateProfile() {
    alert('Профиль обновлен!');
}

function sendSupportRequest() {
    const message = document.getElementById('supportMessage').value;
    alert('Ваше сообщение отправлено: ' + message);
    document.getElementById('supportMessage').value = '';
}