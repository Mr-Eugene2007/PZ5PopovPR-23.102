// Импорт необходимых модулей Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-analytics.js";
import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-database.js";
import { getStorage, ref as storageRef, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-storage.js";

// Конфигурация Firebase для веб-приложения
const firebaseConfig = {
    apiKey: "AIzaSyA0JZ3t8nAcbPlJhx3VZffhyj1eHKlMZVY",
    authDomain: "webgameshop-f3b88.firebaseapp.com",
    databaseURL: "https://webgameshop-f3b88-default-rtdb.firebaseio.com",
    projectId: "webgameshop-f3b88",
    storageBucket: "webgameshop-f3b88.firebasestorage.app",
    messagingSenderId: "206785674970",
    appId: "1:206785674970:web:9256144bd9feb69dac6fe3",
    measurementId: "G-S4KC1TBQ8S"
  };

// Инициализация Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getDatabase(app);
const storage = getStorage(app);

// Функция для загрузки и отображения новостей
async function loadNews() {
    try {
        const gamesList = document.getElementById('gamesList');
        
        // Очищаем список и показываем индикатор загрузки
        gamesList.innerHTML = `
            <div class="text-center py-8 col-span-3">
                <div class="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-yellow-500"></div>
                <p class="text-black mt-2">Загрузка новостей</p>
            </div>
        `;

        const newsRef = ref(db, 'News');
        const snapshot = await get(newsRef);
        
        if (!snapshot.exists()) {
            gamesList.innerHTML = '<p class="text-black col-span-3 text-center">Новостей пока нет</p>';
            return;
        }

        const gamesData = [];
        snapshot.forEach((childSnapshot) => {
            const game = childSnapshot.val();
            gamesData.push({
                id: childSnapshot.key,
                title: game.AppID || 'Без названия',
                developer: game.ID_Developer || 'Неизвестный разработчик',
                publisher: game.ID_Publishes || 'Неизвестный издатель',
                imageUrl: game.Image || '',
            });
        });

        // Очищаем список перед добавлением новых элементов
        gamesList.innerHTML = '';

        // Создаем элементы для каждой игры
        gamesData.forEach(game => {
            const gameElement = document.createElement('div');
            gameElement.className = "bg-white p-6 rounded-lg shadow-lg flex flex-col";
            
            gameElement.innerHTML = `
                ${game.imageUrl ? `<img src="${game.imageUrl}" alt="${game.title}" class="w-full h-48 object-cover rounded-md mb-4">` : 
                  '<div class="w-full h-48 bg-gray-200 rounded-md mb-4 flex items-center justify-center text-gray-500">Изображение отсутствует</div>'}
                <h3 class="text-xl font-bold text-black mb-2">${game.title}</h3>
                <p class="text-black mb-1 text-sm">Разработчик: ${game.developer}</p>
                <p class="text-black mb-4 text-sm">Издатель: ${game.publisher}</p>
                <button class="w-full text-black bg-yellow-300 hover:bg-yellow-400 focus:ring-4 focus:outline-none focus:ring-yellow-300 font-medium rounded-lg text-lg px-6 py-3 text-center dark:bg-orange-400 dark:hover:bg-orange-500 dark:focus:ring-orange-400">
                    Подробнее
                </button>
            `;
            
            gamesList.appendChild(gameElement);
        });

    } catch (error) {
        console.error('Ошибка при загрузке новостей:', error);
        const gamesList = document.getElementById('gamesList');
        gamesList.innerHTML = '<p class="text-red-500 col-span-3 text-center">Произошла ошибка при загрузке новостей</p>';
    }
}

// Загружаем новости при загрузке страницы
document.addEventListener('DOMContentLoaded', loadNews);