// Подключение необходимых модулей Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-app.js";
import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-database.js";

// Конфигурация Firebase
const firebaseConfig = {
    apiKey: "AIzaSyA0JZ3t8nAcbPlJhx3VZffhyj1eHKlMZVY",
    authDomain: "webgameshop-f3b88.firebaseapp.com",
    databaseURL: "https://webgameshop-f3b88-default-rtdb.firebaseio.com",
    projectId: "webgameshop-f3b88",
    storageBucket: "webgameshop-f3b88.firebasestorage.app",
    messagingSenderId: "206785674970",
    appId: "1:206785674970:web:9256144bd9feb69dac6fe3",
    measurementId: "G-S4KC1TBQ8S"
  };

// Инициализация Firebase
const firebaseApp = initializeApp(firebaseConfig);
const database = getDatabase(firebaseApp);

// Функция входа пользователя
async function loginUser() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (!email || !password) {
        Swal.fire({
            icon: "error",
            title: "Ошибка...",
            text: "Введите логин и пароль!",
        });
        return;
    }

    try {
        // Получение данных из коллекции "authorization"
        const snapshot = await get(ref(database, "authorization"));
        const users = snapshot.val();

        const user = Object.values(users).find(u => u.Login.toLowerCase() === email.toLowerCase() && u.Password === password);

        if (user) {
            // Сохраняем ID пользователя для загрузки имени в личном кабинете
            localStorage.setItem("userID", user.ID_Post);
            localStorage.setItem("userEmail", email);

            // Определяем роль и перенаправляем
            const isAdmin = user.ID_Post === "1";
            const isCoach = user.ID_Post === "3";

            if (isAdmin) {
                window.location.href = "index.html";
            } else if (isCoach) {
                window.location.href = "coach.html";
            } else {
                window.location.href = "personalaccount.html";
            }
        } else {
            Swal.fire({
                icon: "error",
                title: "Ошибка...",
                text: "Неправильный логин или пароль!",
            });
        }
    } catch (error) {
        console.error("Ошибка при получении данных пользователя:", error);
    }
}

document.getElementById("authButton").addEventListener("click", loginUser);