document.addEventListener('DOMContentLoaded', async () => {
    await loadCategories();
    await loadProducts();
    
    document.getElementById('search-btn').addEventListener('click', searchProducts);
    document.getElementById('category-filter').addEventListener('change', filterByCategory);
});

async function loadCategories() {
    const { data: categories, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');

    if (error) {
        console.error('Error loading categories:', error);
        return;
    }

    const categoriesList = document.getElementById('categories-list');
    const categoryFilter = document.getElementById('category-filter');

    categoriesList.innerHTML = categories.map(category => `
        <div class="category" data-slug="${category.slug}">
            <h3>${category.name}</h3>
            <p>${category.description}</p>
            <button class="category-btn" data-slug="${category.slug}">Смотреть товары</button>
        </div>
    `).join('');

    categoryFilter.innerHTML = '<option value="all">Все категории</option>' +
        categories.map(category => `
            <option value="${category.slug}">${category.name}</option>
        `).join('');

    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const slug = e.target.getAttribute('data-slug');
            filterByCategory(slug);
        });
    });
}

async function loadProducts(categorySlug = 'all', searchQuery = '') {
    let query = supabase
        .from('products')
        .select('*')
        .eq('is_active', true);

    if (categorySlug !== 'all') {
        const { data: category } = await supabase
            .from('categories')
            .select('id')
            .eq('slug', categorySlug)
            .single();
        
        if (category) {
            query = query.eq('category_id', category.id);
        }
    }

    if (searchQuery) {
        query = query.ilike('name', `%${searchQuery}%`);
    }

    const { data: products, error } = await query;

    if (error) {
        console.error('Error loading products:', error);
        return;
    }

    const productsGrid = document.getElementById('products-grid');
    productsGrid.innerHTML = products.map(product => `
        <div class="product-card" data-id="${product.id}">
            <div class="product-image">
                <img src="${product.image_url || 'https://via.placeholder.com/300x200?text=No+Image'}" alt="${product.name}">
            </div>
            <div class="product-info">
                <h4>${product.name}</h4>
                <p class="product-description">${product.description}</p>
                <p class="product-price">${formatPrice(product.price)}</p>
                <div class="product-actions">
                    <button class="add-to-cart-btn" data-id="${product.id}">В корзину</button>
                    <button class="favorite-btn" data-id="${product.id}">❤️</button>
                </div>
            </div>
        </div>
    `).join('');

    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const productId = e.target.getAttribute('data-id');
            addToCart(productId);
        });
    });

    document.querySelectorAll('.favorite-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const productId = e.target.getAttribute('data-id');
            toggleFavorite(productId);
        });
    });
}

function searchProducts() {
    const searchQuery = document.getElementById('search-input').value;
    const category = document.getElementById('category-filter').value;
    loadProducts(category, searchQuery);
}

function filterByCategory() {
    const category = document.getElementById('category-filter').value;
    loadProducts(category);
}

function formatPrice(price) {
    return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB'
    }).format(price);
}

async function addToCart(productId) {
    const user = getCurrentUser();
    if (!user) {
        alert('Пожалуйста, войдите в систему чтобы добавить товар в корзину');
        window.location.href = 'login.html';
        return;
    }
    alert('Товар добавлен в корзину!');
}

async function toggleFavorite(productId) {
    const user = getCurrentUser();
    if (!user) {
        alert('Пожалуйста, войдите в систему чтобы добавить товар в избранное');
        window.location.href = 'login.html';
        return;
    }

    const { data: existing } = await supabase
        .from('favorites')
        .select('id')
        .eq('user_id', user.id)
        .eq('product_id', productId)
        .single();

    if (existing) {
        await supabase
            .from('favorites')
            .delete()
            .eq('id', existing.id);
        alert('Товар удален из избранного');
    } else {
        await supabase
            .from('favorites')
            .insert([{ user_id: user.id, product_id: productId }]);
        alert('Товар добавлен в избранное!');
    }
}