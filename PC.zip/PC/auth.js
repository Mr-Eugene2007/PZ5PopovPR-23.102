let currentUser = null;

document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (session) {
        currentUser = session.user;
        updateAuthUI(session.user);
    } else {
        updateAuthUI(null);
    }

    supabase.auth.onAuthStateChange((event, session) => {
        currentUser = session ? session.user : null;
        updateAuthUI(currentUser);
        
        if (event === 'SIGNED_IN' && window.location.pathname.includes('account.html')) {
            loadAccountData();
        }
    });
});

function updateAuthUI(user) {
    const loginBtn = document.getElementById('login-btn');
    const userMenu = document.getElementById('user-menu');
    const userName = document.getElementById('user-name');
    const logoutBtn = document.getElementById('logout-btn');
    
    if (user) {
        if (loginBtn) loginBtn.classList.add('hidden');
        if (userMenu) userMenu.classList.remove('hidden');
        if (userName) userName.textContent = user.email;
        
        if (logoutBtn) {
            logoutBtn.onclick = async () => {
                await supabase.auth.signOut();
                window.location.href = 'index.html';
            };
        }
    } else {
        if (loginBtn) {
            loginBtn.classList.remove('hidden');
            loginBtn.onclick = () => {
                window.location.href = 'login.html';
            };
        }
        if (userMenu) userMenu.classList.add('hidden');
    }
}

function getCurrentUser() {
    return currentUser;
}