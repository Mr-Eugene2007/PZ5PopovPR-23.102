document.addEventListener('DOMContentLoaded', async () => {
    await loadPopularProducts();
});

async function loadPopularProducts() {
    const { data: products, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .limit(6)
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Error loading products:', error);
        return;
    }

    const productsGrid = document.getElementById('popular-products');
    if (productsGrid) {
        productsGrid.innerHTML = products.map(product => `
            <div class="product-card" data-id="${product.id}">
                <div class="product-image">
                    <img src="${product.image_url || 'https://via.placeholder.com/300x200?text=No+Image'}" alt="${product.name}">
                </div>
                <div class="product-info">
                    <h4>${product.name}</h4>
                    <p class="product-price">${formatPrice(product.price)}</p>
                    <button class="add-to-cart-btn" data-id="${product.id}">В корзину</button>
                </div>
            </div>
        `).join('');

        document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.target.getAttribute('data-id');
                addToCart(productId);
            });
        });
    }
}

function formatPrice(price) {
    return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB'
    }).format(price);
}

async function addToCart(productId) {
    const user = getCurrentUser();
    if (!user) {
        alert('Пожалуйста, войдите в систему чтобы добавить товар в корзину');
        window.location.href = 'login.html';
        return;
    }
    alert('Товар добавлен в корзину!');
}