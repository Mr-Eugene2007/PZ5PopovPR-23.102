document.querySelectorAll('.service-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const service = this.getAttribute('data-service');
        alert(`Заказ услуги: ${service}\n\nВ реальном приложении здесь бы открывалась форма заказа услуги.`);
    });
});