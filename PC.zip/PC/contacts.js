document.getElementById('feedback-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Сообщение отправлено! Мы свяжемся с вами в ближайшее время.');
    this.reset();
});