document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (session) {
        document.getElementById('auth-required').classList.add('hidden');
        document.getElementById('account-content').classList.remove('hidden');
        await loadAccountData();
        setupTabNavigation();
    } else {
        document.getElementById('auth-required').classList.remove('hidden');
        document.getElementById('go-to-login').addEventListener('click', () => {
            window.location.href = 'login.html';
        });
    }
});

async function loadAccountData() {
    await loadProfile();
    await loadOrders();
    await loadFavorites();
}

async function loadProfile() {
    const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', getCurrentUser().id)
        .single();

    if (error && error.code !== 'PGRST116') {
        console.error('Error loading profile:', error);
        return;
    }

    if (profile) {
        document.getElementById('profile-name').value = profile.full_name || '';
        document.getElementById('profile-phone').value = profile.phone || '';
    }

    document.getElementById('profile-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        await saveProfile();
    });
}

async function saveProfile() {
    const fullName = document.getElementById('profile-name').value;
    const phone = document.getElementById('profile-phone').value;

    const { error } = await supabase
        .from('profiles')
        .upsert({
            id: getCurrentUser().id,
            full_name: fullName,
            phone: phone,
            updated_at: new Date()
        });

    if (error) {
        alert('Ошибка сохранения профиля: ' + error.message);
    } else {
        alert('Профиль успешно сохранен!');
    }
}

async function loadOrders() {
    const { data: orders, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', getCurrentUser().id)
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Error loading orders:', error);
        return;
    }

    const ordersList = document.getElementById('orders-list');
    if (orders.length === 0) {
        ordersList.innerHTML = '<p>У вас пока нет заказов</p>';
    } else {
        ordersList.innerHTML = orders.map(order => `
            <div class="order">
                <p><strong>Заказ #${order.id.slice(-8)}</strong> от ${new Date(order.created_at).toLocaleDateString()}</p>
                <p>Статус: ${getOrderStatusText(order.status)}</p>
                <p>Сумма: ${formatPrice(order.total_amount)}</p>
            </div>
        `).join('');
    }
}

async function loadFavorites() {
    const { data: favorites, error } = await supabase
        .from('favorites')
        .select('products(*)')
        .eq('user_id', getCurrentUser().id);

    if (error) {
        console.error('Error loading favorites:', error);
        return;
    }

    const favoritesList = document.getElementById('favorites-list');
    if (favorites.length === 0) {
        favoritesList.innerHTML = '<p>У вас пока нет избранных товаров</p>';
    } else {
        favoritesList.innerHTML = favorites.map(fav => `
            <div class="product-card" data-id="${fav.products.id}">
                <div class="product-image">
                    <img src="${fav.products.image_url || 'https://via.placeholder.com/300x200?text=No+Image'}" alt="${fav.products.name}">
                </div>
                <div class="product-info">
                    <h4>${fav.products.name}</h4>
                    <p class="product-price">${formatPrice(fav.products.price)}</p>
                    <button class="add-to-cart-btn" data-id="${fav.products.id}">В корзину</button>
                </div>
            </div>
        `).join('');

        document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.target.getAttribute('data-id');
                addToCart(productId);
            });
        });
    }
}

function setupTabNavigation() {
    document.querySelectorAll('.account-menu a').forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            
            document.querySelectorAll('.account-menu a').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            this.classList.add('active');
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
}

function getOrderStatusText(status) {
    const statuses = {
        'pending': 'Ожидание',
        'confirmed': 'Подтвержден',
        'shipped': 'Отправлен',
        'delivered': 'Доставлен',
        'cancelled': 'Отменен'
    };
    return statuses[status] || status;
}

function formatPrice(price) {
    return new Intl.NumberFormat('ru-RU', {
        style: 'currency',
        currency: 'RUB'
    }).format(price);
}

async function addToCart(productId) {
    alert('Товар добавлен в корзину!');
}