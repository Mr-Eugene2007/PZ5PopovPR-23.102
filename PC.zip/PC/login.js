document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = e.target[0].value;
    const password = e.target[1].value;
    
    const { error } = await supabase.auth.signInWithPassword({
        email,
        password
    });
    
    if (error) {
        alert('Ошибка входа: ' + error.message);
    } else {
        window.location.href = 'account.html';
    }
});

document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = e.target[0].value;
    const email = e.target[1].value;
    const password = e.target[2].value;
    
    const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
            data: {
                name: name
            }
        }
    });
    
    if (error) {
        alert('Ошибка регистрации: ' + error.message);
    } else {
        alert('Регистрация успешна! Проверьте вашу почту для подтверждения.');
    }
});