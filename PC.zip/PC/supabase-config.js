const supabaseUrl = 'https://nafdmicvnzfmprzdywof.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5hZmRtaWN2bnpmbXByemR5d29mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTkxNTI0NzgsImV4cCI6MjA3NDcyODQ3OH0.4AlleoWN-I0VzUhaeNKNbQ4stUVy0b1-WtM2sgxg758';

const supabase = window.supabase.createClient(supabaseUrl, supabaseKey);