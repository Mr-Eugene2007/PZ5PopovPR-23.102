document.addEventListener('DOMContentLoaded', async () => {
    await loadNews();
    setupNewsTabs();
});

async function loadNews() {
    const { data: news, error } = await supabase
        .from('news')
        .select('*')
        .lte('published_at', new Date().toISOString())
        .order('published_at', { ascending: false });

    if (error) {
        console.error('Error loading news:', error);
        return;
    }

    const articles = news.filter(item => item.type === 'article');
    const events = news.filter(item => item.type === 'event');

    displayNews('articles', articles);
    displayNews('events', events);
}

function displayNews(categoryId, newsItems) {
    const container = document.getElementById(categoryId);
    if (newsItems.length === 0) {
        container.innerHTML = '<p>Пока нет новостей в этой категории</p>';
    } else {
        container.innerHTML = newsItems.map(item => `
            <div class="news-item">
                <h3>${item.title}</h3>
                <p class="date">${new Date(item.published_at).toLocaleDateString()}</p>
                <p>${item.excerpt || item.content.substring(0, 150)}...</p>
                <a href="#" data-id="${item.id}">Читать далее</a>
            </div>
        `).join('');
    }
}

function setupNewsTabs() {
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.news-category').forEach(c => c.classList.remove('active'));
            
            tab.classList.add('active');
            const categoryId = tab.getAttribute('data-category');
            document.getElementById(categoryId).classList.add('active');
        });
    });
}